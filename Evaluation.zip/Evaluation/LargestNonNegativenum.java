/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Evaluation;

/**
 *
 * @author venkat
 */
import java.util.ArrayList;
import java.util.List;

public class LargestNonNegativenum {
    public static void main(String[] args) {
        int[] array = {2, 7, 5, -1, -3, 2, 9, 7};

        int maxSum = Integer.MIN_VALUE;
        int currentSum = 0;
        List<Integer> currentSubarray = new ArrayList<>();
        List<Integer> maxSubarray = new ArrayList<>();

        for (int num : array) {
            if (num >= 0) {
                currentSum += num;
                currentSubarray.add(num);
                if (currentSum > maxSum) {
                    maxSum = currentSum;
                    maxSubarray = new ArrayList<>(currentSubarray);
                }
            } else {
                currentSum = 0;
                currentSubarray.clear();
            }
        }

        System.out.println("Sum: " + maxSum);
        System.out.print("Elements: ");
        for (int i = 0; i < maxSubarray.size(); i++) {
            System.out.print(maxSubarray.get(i));
            if (i < maxSubarray.size() - 1) {
                System.out.print(", ");
            }
        }
        System.out.println();
    }
}
